
const db = require('../models')
const User = db.users;
const { uuid } = require('uuidv4');
const bcrypt = require('bcrypt');
const moment= require('moment');
const multer = require('multer')
const path = require('path')

const emailValidator = require("email-validator");
const Product = db.products
const addProduct = async (req, res) => {
    if (
      !req.body.username ||
      !req.body.first_name ||
      !req.body.last_name ||
      !req.body.password
    ) {
      res.status(400).send();
    } else {
      const salt = await bcrypt.genSalt(10);
      const hashPassword = await bcrypt.hash(req.body.password, salt);
  
      let info = {
        id:uuid(),
        username: req.body.username,
        last_name: req.body.last_name,
        first_name: req.body.first_name,
        password: hashPassword,
      };
  
      if (
        !emailValidator.validate(`${req.body.username}`) ||
        !req.body.first_name ||
        !req.body.last_name
      ) {
        res.status(400).send();
      } else {
        const findUser = await User.findOne({
          where: { username: `${req.body.username}` },
        });
        if (findUser === null) {
          const user = await User.create(info).then((data) => {
            let plainUser = {
              id: data.id,
              username: data.username,
              first_name: data.first_name,
              last_name: data.last_name,
              account_created: data.createdAt,
              account_updated: data.updatedAt,
            };
  
            res.status(201).json(plainUser);
          });
  
          res.status(201).send();
        } else {
          res.status(400).send();
        }
      }
    }
  };


const getOneProduct = async (req, res) => {
    console.log(db);
    if (req.headers.authorization === undefined) {
      res.status(403).send();
    } else {
      var encoded = req.headers.authorization.split(" ")[1];
      var decoded = new Buffer(encoded, "base64").toString();
      var username = decoded.split(":")[0];
      var password = decoded.split(":")[1];
    
      const findUser = await User.findOne({
        where: { username: username },
      });
      if (findUser !== null) {
        if (await bcrypt.compare(password, findUser.password)) {
          let plainUser = {
            id: findUser.id,
            username: findUser.username,
            first_name: findUser.first_name,
            last_name: findUser.last_name,
            account_created: findUser.createdAt,
            account_updated: findUser.updatedAt,
          };
  
          res.status(200).json(plainUser);
        } else {
          res.status(401).send();
        }
      } else {
        res.status(400).send();
      }
    }
  };

const updateacc = async (req, res) => {
    if (req.body.id || req.body.account_created || req.body.account_updated) {
      res.status(400).send();
    } else {
      if (
        !req.body.username ||
        !req.body.first_name ||
        !req.body.last_name ||
        !req.body.password
      ) {
        res.status(400).send();
      } else {
        if (req.headers.authorization === undefined) {
          res.status(403).send();
        } else {
          var encoded = req.headers.authorization.split(" ")[1];
          var decoded = new Buffer(encoded, "base64").toString();
          var username = decoded.split(":")[0];
          var password = decoded.split(":")[1];
  
          const salt = await bcrypt.genSalt(10);
          const hashPassword = await bcrypt.hash(req.body.password, salt);
  
          const findUser = await User.findOne({
            where: { username: username },
          });
          if (findUser !== null) {
            if (!req.body.first_name || !req.body.last_name || !req.body.password) {
              res.status(400).send();
            } else {
              if (await bcrypt.compare(password, findUser.password)) {
                if (passValidator.validate(`${req.body.password}`)) {
                  findUser.update({
                    first_name: `${req.body.first_name}`,
                    last_name: `${req.body.last_name}`,
                    password: hashPassword,
                  });
                  res.status(204).send();
                } else {
                  res.status(400).send();
                }
              }
              res.status(401).send();
            }
          } else {
            res.status(400).send();
          }
        }
      }
    }
  };

module.exports = {
    addProduct,
    getOneProduct,
    updateacc
}