CSYE- 6225 
## Assignment 1

- Clone this git repositiory to local system 
- go to the folder webapp
- run npm i 
- run node index.js
--
tesar
npm i nodemon - (nodemon --exec npm start)
nodemon start
npm i chai
npm i mocha
npm i mysql
npm test
.......
...
--
